ACADÉMIE MILITAIRE – AKD
Projet Android source + compilation automatique en ligne.

CE ZIP N'EST PAS ENCORE UN APK. Il contient le projet Android et un workflow qui demandera à GitHub de compiler l'APK dans le cloud.

ÉTAPES DEPUIS UN TÉLÉPHONE
1. Décompresser ce ZIP dans l'application Fichiers.
2. Se connecter ou créer un compte sur https://github.com
3. Créer un dépôt nommé AKD-Android.
4. Importer les fichiers et dossiers du projet décompressé dans le dépôt, en conservant impérativement le fichier caché .github/workflows/android-apk.yml.
5. Valider l'envoi (Commit changes) sur la branche main.
6. Ouvrir l'onglet Actions du dépôt et choisir « Construire APK Android AKD ».
7. Attendre la coche verte de réussite, ouvrir l'exécution et télécharger l'archive dans Artifacts : AKD-Android-Demo-APK.
8. Décompresser cette archive : elle contient app-debug.apk.
9. Ouvrir app-debug.apk sur Android et autoriser l'installation si le téléphone le demande.

Si le téléphone masque les fichiers cachés, activer « Afficher les fichiers cachés » dans le gestionnaire de fichiers. Si l'import depuis mobile est difficile, il faudra utiliser un ordinateur ou un service de dépôt Git compatible.

Configuration : Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, compileSdk 35, minSdk 23.

LIMITES
Cette version est une démonstration : pas de vrais comptes, backend, base de données, synchronisation, messagerie, certificats ni Assistant AKD connecté. L'APK debug n'est pas une version de publication Play Store.
Projet indépendant, non officiel. Ne pas publier de documents confidentiels ou opérationnels.
